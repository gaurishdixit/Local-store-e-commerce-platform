import { _ } from '@evershop/evershop/src/lib/locale/translate';

const options = [
  { code: 'price', name: _('Price') },
  { code: 'name', name: _('Name') }
];

export default options;
